<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sales extends CI_Controller 
{
	public function register()
	{
		$this->load->view('Sales/register');
	}
	public function reg()
	{
		$name=$this->input->post('name');
		$email=$this->input->post('email');
		$pswd=$this->input->post('pswd');
		$add=array('name'=>$name,'email'=>$email,'password'=>$pswd);
		$this->load->model('Sales_model');
		$result=$this->Sales_model->register($add);
		if($result==1)
		{
			echo "<script>alert('Success')</script>";
			$this->login();
		}
		else
		{
			echo "<script>alert('Failed')</script>";
			$this->register();
		}
	}
	public function login()
	{
		$this->load->view('Sales/login');
	}
	public function log()
	{
		$email=$this->input->post('email');
		$pswd=$this->input->post('pswd');
		$log=array('email'=>$email,'password'=>$pswd);
		$this->load->model('Sales_model');
		$count=$this->Sales_model->login($log);
		if($count>0)
		{
			echo "<script>alert('Login Success')</script>";
			$this->session->set_userdata('email',$email);
			$this->home();
		}
		else
		{
			echo "<script>alert('Failed')</script>";
			$this->login();
		}
	}
	public function logout()
	{
		$this->session->sess_destroy();
		$this->login();
	}
	public function home()
	{
		if($this->session->has_userdata('email'))
		{
			$this->load->view('Sales/home');
		}
		else
		{
			$this->login();
		}
		
	}
	public function viewtask()
	{
		if($this->session->has_userdata('email'))
		{
			$this->load->model('Sales_model');
			$result['tsk']=$this->Sales_model->viewtask();
			$this->load->view('Sales/viewtask',$result);
		}
		else
		{
			$this->login();
		}
	}
	public function sendreport($id)
	{
		if($this->session->has_userdata('email'))
		{
			$this->load->model('Sales_model');
			$result['tsk']=$this->Sales_model->viewtaskmark($id);
			$this->load->view('Sales/sendreport',$result);
		}
		else
		{
			$this->login();
		}
	}
	public function reportsend()
	{
		$aid=$this->input->post('aid');
		$report=$this->input->post('report');
		$date=date('y-m-d');
		$time=date_default_timezone_set("Asia/Calcutta");
		$time=date('h:i A');
		$update=array('report'=>$report,'rdate'=>$date,'rtime'=>$time);
		$this->load->model('Sales_model');
		$result=$this->Sales_model->updatetask($update,$aid);
		if($result==1)
		{
			echo "<script>alert('Updation success')</script>";
			$this->viewtask();
		}
		else
		{
			echo "<script>alert('Failed')</script>";
			$this->viewtask();
		}
	}
	public function addcustomer()
	{
		if($this->session->has_userdata('email'))
		{
			$this->load->view('Sales/addcustomers');
		}
		else
		{
			$this->login();
		}
	}
	public function customeradd()
	{
		$smail=$this->session->userdata('email');
		$name=$this->input->post('name');
		$email=$this->input->post('email');
		$address=$this->input->post('address');
		$mobile=$this->input->post('mobile');
		$date=date('y-m-d');
		$add=array('salemail'=>$smail,'name'=>$name,'email'=>$email,'address'=>$address,'mobile'=>$mobile,'date'=>$date);
		$this->load->model('Sales_model');
		$result=$this->Sales_model->customer($add);
		if($result==1)
		{
			echo "<script>alert('Added')</script>";
			$this->addcustomer();
		}
		else
		{
			echo "<script>alert('Failed')</script>";
			$this->addcustomer();
		}
	}
	public function viewcustomer()
	{
		if($this->session->has_userdata('email'))
		{
			$this->load->model('Sales_model');
			$result['cstmr']=$this->Sales_model->viewcustomer();
			$this->load->view('Sales/viewcustomer',$result);
		}
		else
		{
			$this->login();
		}
	}
	public function editcustomer($id)
	{
		$this->load->model('Sales_model');
		$result['cstmr']=$this->Sales_model->viewcustomer1($id);
		$this->load->view('Sales/vieweditcustomer',$result);
	}
	public function customeredit()
	{
		$id=$this->input->post('id');
		$name=$this->input->post('name');
		$email=$this->input->post('email');
		$address=$this->input->post('address');
		$mobile=$this->input->post('mobile');
		$add=array('name'=>$name,'email'=>$email,'address'=>$address,'mobile'=>$mobile);
		$this->load->model('Sales_model');
		$result=$this->Sales_model->customeredit($add,$id);
		if($result==1)
		{
			echo "<script>alert('Updated')</script>";
			$this->viewcustomer();
		}
		else
		{
			echo "<script>alert('Failed')</script>";
			$this->viewcustomer();
		}
	}
	public function deletecustomer($id)
	{
		$this->load->model('Sales_model');
		$result=$this->Sales_model->customerdelete($id);
		if($result==1)
		{
			echo "<script>alert('Deleted')</script>";
			$this->viewcustomer();
		}
		else
		{
			echo "<script>alert('Failed')</script>";
			$this->viewcustomer();
		}
	}
	public function profile()
	{
		$this->load->model('Sales_model');
		$result['mr']=$this->Sales_model->profile();
		$this->load->view('Sales/viewprofile',$result);
	}
	public function editprofile()
	{
		$name=$this->input->post('name');
		$pswd=$this->input->post('pswd');
		$add=array('name'=>$name,'password'=>$pswd);
		$this->load->model('Sales_model');
		$result=$this->Sales_model->profileedit($add);
		if($result==1)
		{
			echo "<script>alert('Updated')</script>";
			$this->profile();
		}
		else
		{
			echo "<script>alert('Failed')</script>";
			$this->profile();
		}
	}


}