<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Manager extends CI_Controller 
{
	public function register()
	{
		$this->load->view('Manager/register');
	}
	public function reg()
	{
		$email=$this->input->post('email');
		$pswd=$this->input->post('pswd');
		$add_register=array('email'=>$email,'password'=>$pswd);
		$this->load->model('Manager_model');
		$result=$this->Manager_model->register($add_register);
		if($result==1)
		{
			echo "<script>alert('Registration success')</script>";
			$this->login();
		}
		else
		{
			echo "<script>alert('Registration failed')</script>";
			$this->login();
		}
	}
	public function login()
	{
		$this->load->view('Manager/login');
	}
	public function log()
	{
		$email=$this->input->post('email');
		$pswd=$this->input->post('pswd');
		$login=array('email'=>$email,'password'=>$pswd);
		$this->load->model('Manager_model');
		$count=$this->Manager_model->login($login);
		if($count>0)
		{
			echo "<script>alert('Login success')</script>";
			$this->session->set_userdata('email',$email);
			$this->home();
		}
		else
		{
			echo "<script>alert('Login failed')</script>";
			$this->login();
		}
	}
	public function logout()
	{
		$this->session->sess_destroy();
		$this->login();
	}
	public function home()
	{
		if($this->session->has_userdata('email'))
		{
			$this->load->model('Manager_model');
			$result['mar']=$this->Manager_model->countmarket();
			$result['sale']=$this->Manager_model->countsales();
			$this->load->view('Manager/Home',$result);
		}
		else
		{
			$this->login();
		}
		
	}
	public function addtask()
	{
		if($this->session->has_userdata('email'))
		{
			$this->load->view('Manager/add_task');
		}
		else
		{
			$this->login();
		}
	}
	public function taskadd()
	{
		$task=$this->input->post('task');
		$t1=array('task'=>$task);
		$this->load->model('Manager_model');
		$result=$this->Manager_model->taskadd($t1);
		if($result==1)
		{
			echo "<script>alert('Task added')</script>";
			$this->viewtask();
		}
		else
		{
			echo "<script>alert('failed')</script>";
			$this->addtask();
		}
	}
	public function viewtask()
	{
		if($this->session->has_userdata('email'))
		{
			$this->load->model('Manager_model');
			$task['tsk']=$this->Manager_model->viewtask();
			$this->load->view('Manager/viewtask',$task);
		}
		else
		{
			$this->login();
		}
	}
	public function edittask($id)
	{
		$this->load->model('Manager_model');
		$task['tsk']=$this->Manager_model->viewedittask($id);
		$this->load->view('Manager/edittask',$task);
	}
	public function taskedit()
	{
		$id=$this->input->post('id');
		$task=$this->input->post('task');
		$edit=array('task'=>$task);
		$this->load->model('Manager_model');
		$result=$this->Manager_model->taskedit($edit,$id);
		if($result==1)
		{
			echo "<script>alert('Updated')</script>";
			$this->viewtask();
		}
		else
		{
			echo "<script>alert('Failed')</script>";
			$this->viewtask();
		}

	}
	public function deletetask($id)
	{
		$this->load->model('Manager_model');
		$result=$this->Manager_model->deletetask($id);
		if($result==1)
		{
			echo "<script>alert('Deleted')</script>";
			$this->viewtask();
		}
		else
		{
			echo "<script>alert('Failed')</script>";
			$this->viewtask();
		}
	}
	public function add_users1()
	{
		if($this->session->has_userdata('email'))
		{
			$this->load->view('Manager/Add_marketing');
		}
		else
		{
			$this->login();
		}
		
	}
	public function marketadd()
	{
		$name=$this->input->post('name');
		$email=$this->input->post('email');
		$pswd=$this->input->post('pswd');
		$add=array('name'=>$name,'email'=>$email,'password'=>$pswd);
		$this->load->model('Marketing_model');
		$result=$this->Marketing_model->register($add);
		if($result==1)
		{
			echo "<script>alert('Registration success')</script>";
			$this->add_users1();
		}
		else
		{
			echo "<script>alert('Registration failed')</script>";
			$this->add_users1();
		}
	}
	public function view_users1()
	{
		if($this->session->has_userdata('email'))
		{
			$this->load->model('Marketing_model');
			$market['mr']=$this->Marketing_model->viewmarket();
			//$market['tsk']=$this->Manager_model->marketview();
			$this->load->view('Manager/viewmarket',$market);
		}
		else
		{
			$this->login();
		}
		
	}
	public function editmarket($id)
	{
		$this->load->model('Manager_model');
		$result['cats']=$this->Manager_model->vieweditmarket($id);
		$this->load->view('Manager/vieweditmarket',$result);
	}
	public function marketedit()
	{
		$id=$this->input->post('id');
		$name=$this->input->post('name');
		$editmar=array('name'=>$name);
		$this->load->model('Manager_model');
		$result=$this->Manager_model->marketedit($editmar,$id);
		if($result==1)
		{
			echo "<script>alert('Success')</script>";
			$this->view_users1();
		}
		else
		{
			echo "<script>alert('Failed')</script>";
			$this->view_users1();
		}

	}
	public function deletemarket($id)
	{
		$this->load->model('Manager_model');
		$result=$this->Manager_model->deletemarket($id);
		if($result==1)
		{
			echo "<script>alert('Deleted')</script>";
			$this->view_users1();
		}
		else
		{
			echo "<script>alert('Failed')</script>";
			$this->view_users1();
		}
	}
	public function assignedtask()
	{
		if($this->session->has_userdata('email'))
		{
			$this->load->model('Manager_model');
			$market['tsk']=$this->Manager_model->marketview();
			$this->load->view('Manager/viewassign',$market);
		}
		else
		{
			$this->login();
		}
	}
	public function create_task1($id)
	{
		$this->load->model('Manager_model');
		$task['mark']=$this->Manager_model->vieweditmarket($id);
		$task['tsk']=$this->Manager_model->viewtask();
		$this->load->view('Manager/createtask',$task);
	}
	public function task_create1()
	{
		$mid=$this->input->post('markid');
		$tid=$this->input->post('taskid');
		$email=$this->input->post('email');
		$date=date('y-m-d');
		$time=date_default_timezone_set("Asia/Calcutta");
		$time=date('h:i A');
		$create=array('taskid'=>$tid,'markid'=>$email,'salesid'=>"",'date'=>$date,'time'=>$time,'report'=>"",'rdate'=>"",'rtime'=>"");
		$this->load->model('Manager_model');
		$result=$this->Manager_model->createtask($create);
		if($result==1)
		{
			echo "<script>alert('Task created')</script>";
			$this->view_users1();
		}
		else
		{
			echo "<script>alert('Failed')</script>";
			$this->view_users1();
		}
	}




	public function add_users2()
	{
		if($this->session->has_userdata('email'))
		{
			$this->load->view('Manager/addsale');
		}
		else
		{
			$this->login();
		}
		
	}
	public function salesadd()
	{
		$name=$this->input->post('name');
		$email=$this->input->post('email');
		$pswd=$this->input->post('pswd');
		$add=array('name'=>$name,'email'=>$email,'password'=>$pswd);
		$this->load->model('Sales_model');
		$result=$this->Sales_model->register($add);
		if($result==1)
		{
			echo "<script>alert('Registration success')</script>";
			$this->add_users2();
		}
		else
		{
			echo "<script>alert('Registration failed')</script>";
			$this->add_users2();
		}
	}
	public function view_users2()
	{
		if($this->session->has_userdata('email'))
		{
			$this->load->model('Manager_model');
			$sale['sl']=$this->Manager_model->viewsale();
			//$market['tsk']=$this->Manager_model->marketview();
			$this->load->view('Manager/viewsale',$sale);
		}
		else
		{
			$this->login();
		}
		
	}
	public function editsale($id)
	{
		$this->load->model('Manager_model');
		$result['sale']=$this->Manager_model->vieweditsale($id);
		$this->load->view('Manager/vieweditsale',$result);
	}
	public function saleedit()
	{
		$id=$this->input->post('id');
		$name=$this->input->post('name');
		$editsale=array('name'=>$name);
		$this->load->model('Manager_model');
		$result=$this->Manager_model->saleedit($editsale,$id);
		if($result==1)
		{
			echo "<script>alert('Success')</script>";
			$this->view_users2();
		}
		else
		{
			echo "<script>alert('Failed')</script>";
			$this->view_users2();
		}

	}
	public function deletesale($id)
	{
		$this->load->model('Manager_model');
		$result=$this->Manager_model->deletesale($id);
		if($result==1)
		{
			echo "<script>alert('Deleted')</script>";
			$this->view_users2();
		}
		else
		{
			echo "<script>alert('Failed')</script>";
			$this->view_users2();
		}
	}
	public function assignedtask1()
	{
		if($this->session->has_userdata('email'))
		{
			$this->load->model('Manager_model');
			$sale['tsk']=$this->Manager_model->saleview();
			$this->load->view('Manager/viewassign1',$sale);
		}
		else
		{
			$this->login();
		}
	}
	public function create_task2($id)
	{
		$this->load->model('Manager_model');
		$task['sale']=$this->Manager_model->vieweditsale($id);
		$task['tsk']=$this->Manager_model->viewtask();
		$this->load->view('Manager/createtask1',$task);
	}
	public function task_create2()
	{
		$sid=$this->input->post('saleid');
		$tid=$this->input->post('taskid');
		$email=$this->input->post('email');
		$date=date('y-m-d');
		$time=date_default_timezone_set("Asia/Calcutta");
		$time=date('h:i A');
		$create=array('taskid'=>$tid,'markid'=>"",'salesid'=>$email,'date'=>$date,'time'=>$time);
		$this->load->model('Manager_model');
		$result=$this->Manager_model->createtask1($create);
		if($result==1)
		{
			echo "<script>alert('Task created')</script>";
			$this->view_users2();
		}
		else
		{
			echo "<script>alert('Failed')</script>";
			$this->view_users2();
		}
	}

	



}



