<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mark extends CI_Controller
{
	public function login()
	{
		$this->load->view('Mark/login');
	}
	public function log()
	{
		$email=$this->input->post('email');
		$pswd=$this->input->post('pswd');
		$log=array('email'=>$email,'password'=>$pswd);
		$this->load->model('Mark_model');
		$count=$this->Mark_model->login($log);
		if($count>0)
		{
			$this->session->set_userdata('email',$email);
			"<script>alert('Login Succesfully')</script>";
			$this->home();
		}
		else
		{
			$this->login();
		}
	}
	public function home()
	{
		if($this->session->has_userdata('email'))
		{
			$this->load->view('Mark/home');
		}
		else
		{
			$this->login();
		}
	}





}