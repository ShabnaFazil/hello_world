<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Marketing extends CI_Controller 
{
	public function register()
	{
		$this->load->view('Marketing/register');
	}
	public function reg()
	{
		$name=$this->input->post('name');
		$email=$this->input->post('email');
		$pswd=$this->input->post('pswd');
		$add=array('name'=>$name,'email'=>$email,'password'=>$pswd);
		$this->load->model('Marketing_model');
		$result=$this->Marketing_model->register($add);
		if($result==1)
		{
			echo "<script>alert('Registration success')</script>";
			$this->login();
		}
		else
		{
			echo "<script>alert('Registration failed')</script>";
			$this->login();
		}
	}
	public function login()
	{
		$this->load->view('Marketing/login');
	}
	public function log()
	{
		$email=$this->input->post('email');
		$pswd=$this->input->post('pswd');
		$log=array('email'=>$email,'password'=>$pswd);
		$this->load->model('Marketing_model');
		$count=$this->Marketing_model->login($log);
		if($count>0)
		{
			echo "<script>alert('Login success')</script>";
			$this->session->set_userdata('email',$email);
			$this->home();
		}
		else
		{
			echo "<script>alert('Login failed')</script>";
			$this->login();
		}
	}
	public function logout()
	{
		$this->session->sess_destroy();
		$this->login();
	}
	public function home()
	{
		if($this->session->has_userdata('email'))
		{
			$this->load->model('Marketing_model');
			$result['count1']=$this->Marketing_model->counttask();
			$result['count2']=$this->Marketing_model->countuser();
			$this->load->view('Marketing/home',$result);
		}
		else
		{
			$this->login();
		}
	}
	public function viewtask()
	{
		if($this->session->has_userdata('email'))
		{
			$this->load->model('Marketing_model');
			$result['tsk']=$this->Marketing_model->viewtask();
			$this->load->view('Marketing/viewtask',$result);
		}
		else
		{
			$this->login();
		}
	}
	public function sendreport($id)
	{
		if($this->session->has_userdata('email'))
		{
			$this->load->model('Marketing_model');
			$result['tsk']=$this->Marketing_model->viewtaskmark($id);
			$this->load->view('Marketing/sendreport',$result);
		}
		else
		{
			$this->login();
		}
	}
	public function reportsend()
	{
		$aid=$this->input->post('aid');
		$report=$this->input->post('report');
		$date=date('y-m-d');
		$time=date_default_timezone_set("Asia/Calcutta");
		$time=date('h:i A');
		$update=array('report'=>$report,'rdate'=>$date,'rtime'=>$time);
		$this->load->model('Marketing_model');
		$result=$this->Marketing_model->updatetask($update,$aid);
		if($result==1)
		{
			echo "<script>alert('Updation success')</script>";
			$this->viewtask();
		}
		else
		{
			echo "<script>alert('Failed')</script>";
			$this->viewtask();
		}
	}
	public function addcustomer()
	{
		if($this->session->has_userdata('email'))
		{
			$this->load->view('Marketing/addcustomers');
		}
		else
		{
			$this->login();
		}
	}
	public function customeradd()
	{
		$smail=$this->session->userdata('email');
		$name=$this->input->post('name');
		$email=$this->input->post('email');
		$address=$this->input->post('address');
		$mobile=$this->input->post('mobile');
		$date=date('y-m-d');
		$add=array('salemail'=>$smail,'name'=>$name,'email'=>$email,'address'=>$address,'mobile'=>$mobile,'date'=>$date);
		$this->load->model('Marketing_model');
		$result=$this->Marketing_model->customer($add);
		if($result==1)
		{
			echo "<script>alert('Added')</script>";
			$this->addcustomer();
		}
		else
		{
			echo "<script>alert('Failed')</script>";
			$this->addcustomer();
		}
	}
	public function viewcustomer()
	{
		if($this->session->has_userdata('email'))
		{
			$this->load->model('Marketing_model');
			$result['cstmr']=$this->Marketing_model->viewcustomer();
			$this->load->view('Marketing/viewcustomer',$result);
		}
		else
		{
			$this->login();
		}
	}
	public function editcustomer($id)
	{
		$this->load->model('Marketing_model');
		$result['cstmr']=$this->Marketing_model->viewcustomer1($id);
		$this->load->view('Marketing/vieweditcustomer',$result);
	}
	public function customeredit()
	{
		$id=$this->input->post('id');
		$name=$this->input->post('name');
		$email=$this->input->post('email');
		$address=$this->input->post('address');
		$mobile=$this->input->post('mobile');
		$add=array('name'=>$name,'email'=>$email,'address'=>$address,'mobile'=>$mobile);
		$this->load->model('Marketing_model');
		$result=$this->Marketing_model->customeredit($add,$id);
		if($result==1)
		{
			echo "<script>alert('Updated')</script>";
			$this->viewcustomer();
		}
		else
		{
			echo "<script>alert('Failed')</script>";
			$this->viewcustomer();
		}
	}
	public function deletecustomer($id)
	{
		$this->load->model('Marketing_model');
		$result=$this->Marketing_model->customerdelete($id);
		if($result==1)
		{
			echo "<script>alert('Deleted')</script>";
			$this->viewcustomer();
		}
		else
		{
			echo "<script>alert('Failed')</script>";
			$this->viewcustomer();
		}
	}
	public function profile()
	{
		$this->load->model('Marketing_model');
		$result['mr']=$this->Marketing_model->profile();
		$this->load->view('Marketing/viewprofile',$result);
	}
	public function editprofile()
	{
		$name=$this->input->post('name');
		$pswd=$this->input->post('pswd');
		$add=array('name'=>$name,'password'=>$pswd);
		$this->load->model('Marketing_model');
		$result=$this->Marketing_model->profileedit($add);
		if($result==1)
		{
			echo "<script>alert('Updated')</script>";
			$this->profile();
		}
		else
		{
			echo "<script>alert('Failed')</script>";
			$this->profile();
		}
	}


}