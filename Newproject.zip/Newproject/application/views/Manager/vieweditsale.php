<?php
$this->load->view('Manager/Header');
?>

	<div class="form-w3layouts">
        <!-- page start-->
        <!-- page start-->
        <div class="row">
            <div class="col-lg-12">
                    <section class="panel">
                        <header class="panel-heading">
                            Update Sales details
                        </header>
                        <div class="panel-body">
                            <div class="position-center">
                                <?php
                                    foreach($sale as $rows); 
                                ?>
                                <form role="form" method="post" action="<?php echo base_url('index.php/Manager/saleedit');?>">
                                    <input type="hidden" class="form-control"  name="id" value="<?php echo $rows->id;?>">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Name</label>
                                    <input type="text" class="form-control" id="exampleInputEmail1" value="<?php echo $rows->name;?>" name="name">
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Email address</label>
                                    <input type="email" class="form-control" id="exampleInputEmail1" value="<?php echo $rows->email;?>" name="email" readonly>
                                </div>
                                
                                
                                
                                <button type="submit" class="btn btn-info">Update</button>
                            </form>
                            </div>

                        </div>
                    </section>

            </div>
            
        </div>

        </div>
        </div>


        <!-- page end-->
        </div>
<?php
$this->load->view('Manager/Footer');
?>