<?php
$this->load->view('Manager/Header');
?>
<div class="table-agile-info">
 <div class="panel panel-default">
    <div class="panel-heading">
     Assigned tasks
    </div>
    <div>
      <table class="table" ui-jq="footable" ui-options='{
        "paging": {
          "enabled": true
        },
        "filtering": {
          "enabled": true
        },
        "sorting": {
          "enabled": true
        }}'>
        <thead>
          <tr>
            <th data-breakpoints="xs">Sl no</th>
            <th>Name</th>
            <th>Email</th>
            <th>Assigned task</th>
            <th>Date</th>
            <th>Time</th>
            <th>Report</th>
            <th>Date</th>
            <th>Time</th>
          </tr>
        </thead>
        <tbody>
            <?php
                $i=1;
                foreach ($tsk as $row) 
                {
            ?>
          <tr data-expanded="true">
            <td><?php echo $i;?></td>
            <td><?php echo $row->name?></td>
            <td><?php echo $row->email?></td>
            <td><?php echo $row->task?></td>
            <td><?php echo $row->date?></td>
            <td><?php echo $row->time?></td>
            <td><?php echo $row->report?></td>
            <td><?php echo $row->rdate?></td>
            <td><?php echo $row->rtime?></td>
          </tr>
            <?php
                $i++;
                }
            ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php
$this->load->view('Manager/Footer');
?>