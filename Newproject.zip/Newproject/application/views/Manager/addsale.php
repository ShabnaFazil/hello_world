<?php
$this->load->view('Manager/Header');
?>

	<div class="form-w3layouts">
        <!-- page start-->
        <!-- page start-->
        <div class="row">
            <div class="col-lg-12">
                    <section class="panel">
                        <header class="panel-heading">
                            Add Sales details
                        </header>
                        <div class="panel-body">
                            <div class="position-center">
                                <form role="form" method="post" action="<?php echo base_url('index.php/Manager/salesadd');?>">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Name</label>
                                    <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Enter name" name="name">
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Email address</label>
                                    <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Enter email" name="email">
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword1">Password</label>
                                    <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password" name="pswd">
                                </div>
                                
                                
                                <button type="submit" class="btn btn-info">Add</button>
                            </form>
                            </div>

                        </div>
                    </section>

            </div>
            
        </div>

        </div>
        </div>


        <!-- page end-->
        </div>
<?php
$this->load->view('Manager/Footer');
?>