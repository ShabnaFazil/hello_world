<?php
$this->load->view('Manager/Header');
?>

	<div class="form-w3layouts">
        <!-- page start-->
        <!-- page start-->
        <div class="row">
            <div class="col-lg-12">
                    <section class="panel">
                        <header class="panel-heading">
                            View report
                        </header>
                        <div class="panel-body">
                            <div class="position-center">
                                <form role="form" method="post" action="<?php echo base_url('index.php/Manager/salereport');?>">
                                   <!--  <input type="hidden" class="form-control" id="exampleInputEmail1"  name="markid" value="<?php echo $row->id?>"> -->
                               <div class="form-group">
                                    <label for="exampleInputPassword1">Select</label>
                                    <select name="id" style="display: block;width: 100%;height: 34px;padding: 6px 12px;font-size: 14px;line-height: 1.42857143;color: #555;background-color: #fff;background-image: none;border: 1px solid #ccc;border-radius: 4px;">
                                        <?php
                                        foreach($mr as $rows)
                                        {
                                            ?>
                                        
                                        <option value="<?php echo $rows->id;?>"><?php echo $rows->name;?></option>
                                        <?php
                                            }
                                        ?>
                                    </select>
                                </div>

                                
                                
                                <button type="submit" class="btn btn-info">View</button>
                            </form>
                            </div>

                        </div>
                    </section>

            </div>
            
        </div>

        </div>
        </div>


        <!-- page end-->
        </div>
<?php
$this->load->view('Manager/Footer');
?>