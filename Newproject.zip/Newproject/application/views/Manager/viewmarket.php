<?php
$this->load->view('Manager/Header');
?>
<div class="table-agile-info">
 <div class="panel panel-default">
    <div class="panel-heading">
     Marketing details
    </div>
    <div>
      <table class="table" ui-jq="footable" ui-options='{
        "paging": {
          "enabled": true
        },
        "filtering": {
          "enabled": true
        },
        "sorting": {
          "enabled": true
        }}'>
        <thead>
          <tr>
            <th data-breakpoints="xs">Sl no</th>
            <th>Name</th>
            <th>Email</th>
            <th data-breakpoints="xs">Edit</th>
            <th data-breakpoints="xs">Delete</th>
            <th data-breakpoints="xs">Create Task</th>
          </tr>
        </thead>
        <tbody>
        	<?php
        		$i=1;
        		foreach ($mr as $row) 
        		{
        	?>
          <tr data-expanded="true">
            <td><?php echo $i;?></td>
            <td><?php echo $row->name?></td>
            <td><?php echo $row->email?></td>
            <td><button><a href="<?php echo base_url('index.php/Manager/editmarket/'.$row->id);?>">Edit</a></button></td>
            <td><button><a href="<?php echo base_url('index.php/Manager/deletemarket/'.$row->id);?>">Delete</a></button></td>
            <!-- <td><button><a href="<?php echo base_url('index.php/Manager/create_task1/'.$row->id);?>">Create task</a></button></td> -->
            <td><button><a href="<?php echo base_url('index.php/Manager/create_task1/'.$row->id);?>">Create task</a></button></td>
          </tr>
          	<?php
          		$i++;
      			}
      		?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php
$this->load->view('Manager/Footer');
?>