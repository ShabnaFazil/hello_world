<?php
$this->load->view('Manager/Header');
?>
<div class="table-agile-info">
 <div class="panel panel-default">
    <div class="panel-heading">
     Task details
    </div>
    <div>
      <table class="table" ui-jq="footable" ui-options='{
        "paging": {
          "enabled": true
        },
        "filtering": {
          "enabled": true
        },
        "sorting": {
          "enabled": true
        }}'>
        <thead>
          <tr>
            <th data-breakpoints="xs">Sl no</th>
            <th>Task</th>
            <th data-breakpoints="xs">Edit</th>
            <th data-breakpoints="xs">Delete</th>
          </tr>
        </thead>
        <tbody>
        	<?php
        		$i=1;
        		foreach ($tsk as $row) 
        		{
        	?>
          <tr data-expanded="true">
            <td><?php echo $i;?></td>
            <td><?php echo $row->task?></td>
            <td><button><a href="<?php echo base_url('index.php/Manager/edittask/'.$row->id);?>">Edit</a></button></td>
            <td><button><a href="<?php echo base_url('index.php/Manager/deletetask/'.$row->id);?>">Delete</a></button></td>
          </tr>
          	<?php
          		$i++;
      			}
      		?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php
$this->load->view('Manager/Footer');
?>