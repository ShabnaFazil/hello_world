<?php
$this->load->view('Manager/Header');
?>

	<div class="form-w3layouts">
        <!-- page start-->
        <!-- page start-->
        <div class="row">
            <div class="col-lg-12">
                    <section class="panel">
                        <header class="panel-heading">
                            Add task
                        </header>
                        <div class="panel-body">
                            <div class="position-center">
                                <form role="form" method="post" action="<?php echo base_url('index.php/Manager/taskadd');?>">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Enter new task</label>
                                    <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Enter task" name="task">
                                </div>
                    
                                <button type="submit" class="btn btn-info">Add</button>
                            </form>
                            </div>

                        </div>
                    </section>

            </div>
            
        </div>

        </div>
        </div>


        <!-- page end-->
        </div>
<?php
$this->load->view('Manager/Footer');
?>