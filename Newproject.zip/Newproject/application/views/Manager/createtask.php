<?php
$this->load->view('Manager/Header');
?>

	<div class="form-w3layouts">
        <!-- page start-->
        <!-- page start-->
        <div class="row">
            <div class="col-lg-12">
                    <section class="panel">
                        <header class="panel-heading">
                            Task details
                        </header>
                        <div class="panel-body">
                            <div class="position-center">
                                <?php
                                foreach($mark as $row);?>
                                <form role="form" method="post" action="<?php echo base_url('index.php/Manager/task_create1');?>">
                                    <input type="hidden" class="form-control" id="exampleInputEmail1"  name="markid" value="<?php echo $row->id?>">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Name</label>
                                    <input type="text" class="form-control" id="exampleInputEmail1"  name="name" value="<?php echo $row->name?>">
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Email address</label>
                                    <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Enter email" name="email" value="<?php echo $row->email?>">
                                </div>
                               <div class="form-group">
                                    <label for="exampleInputPassword1">Select a task</label>
                                    <select name="taskid" style="display: block;width: 100%;height: 34px;padding: 6px 12px;font-size: 14px;line-height: 1.42857143;color: #555;background-color: #fff;background-image: none;border: 1px solid #ccc;border-radius: 4px;">
                                        <?php
                                        foreach($tsk as $rows)
                                        {
                                            ?>
                                        
                                        <option value="<?php echo $rows->id;?>"><?php echo $rows->task;?></option>
                                        <?php
                                            }
                                        ?>
                                    </select>
                                </div>

                                
                                
                                <button type="submit" class="btn btn-info">Create</button>
                            </form>
                            </div>

                        </div>
                    </section>

            </div>
            
        </div>

        </div>
        </div>


        <!-- page end-->
        </div>
<?php
$this->load->view('Manager/Footer');
?>