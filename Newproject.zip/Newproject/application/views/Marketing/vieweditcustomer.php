<?php
$this->load->view('Marketing/Header');
?>
<div id="page-wrapper">
			<div class="main-page">
				<div class="forms">
					<div class="row">
						<h4>Update customers</h4>
						</div>
						<div class="form-body">
							<?php
								foreach($cstmr as $row)
									?>
							<form method="post" action="<?php echo base_url('index.php/Marketing/customeredit')?>">
							<input type="hidden" class="form-control" id="exampleInputEmail1" placeholder="" name="id" value="<?php echo $row->id?>">  
								<div class="form-group"> 
									<label for="exampleInputEmail1">Name</label> 
									<input type="text" class="form-control" id="exampleInputEmail1" placeholder="Name" name="name" value="<?php echo $row->name?>"> 
								</div>
								<div class="form-group"> 
									<label for="exampleInputEmail1">Email</label> 
									<input type="email" class="form-control" id="exampleInputEmail1" placeholder="Email" name="email" value="<?php echo $row->email?>"> 
								</div> 
								<div class="form-group"> 
									<label for="exampleInputPassword1">Address</label> 
									<input type="text" class="form-control" id="exampleInputPassword1" placeholder="Address" name="address" value="<?php echo $row->address?>"> 
								</div> 
								<div class="form-group"> 
									<label for="exampleInputPassword1">Mobile number</label> 
									<input type="text" class="form-control" id="exampleInputPassword1" placeholder="+91" name="mobile" maxlength="10" value="<?php echo $row->mobile?>"> 
								</div> 
						</div> 
						<button type="submit" class="btn btn-default" style="display: inline-block;
    margin-right: 500;
    text-align: center;
    vertical-align: right;
    text-transform: uppercase;
    cursor: pointer;">Submit</button> 
							</form> 
						</div>

<?php
$this->load->view('Marketing/Footer');
?>