<!-- for amcharts js -->
			<script src="<?php echo base_url('Assets/Marketing/js/amcharts.js');?>"></script>
			<script src="<?php echo base_url('Assets/Marketing/js/serial.js');?>"></script>
			<script src="<?php echo base_url('Assets/Marketing/js/export.min.js');?>"></script>
			<link rel="stylesheet" href="<?php echo base_url('Assets/Marketing/css/export.css');?>" type="text/css" media="all" />
			<script src="<?php echo base_url('Assets/Marketing/js/light.js');?>"></script>
	<!-- for amcharts js -->

    <script  src="<?php echo base_url('Assets/Marketing/js/index1.js');?>"></script>
		
			</div>
		</div>
	<!--footer-->
	<div class="footer">
	   <p>&copy; 2018 Glance Design Dashboard. All Rights Reserved </p>		
	</div>
    <!--//footer-->
	</div>
		
	<!-- new added graphs chart js-->
	
    <script src="<?php echo base_url('Assets/Marketing/js/Chart.bundle.js');?>"></script>
    <script src="<?php echo base_url('Assets/Marketing/js/utils.js');?>"></script>
	
	<script>
        var MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
        var color = Chart.helpers.color;
        var barChartData = {
            labels: ["January", "February", "March", "April", "May", "June", "July"],
            datasets: [{
                label: 'Dataset 1',
                backgroundColor: color(window.chartColors.red).alpha(0.5).rgbString(),
                borderColor: window.chartColors.red,
                borderWidth: 1,
                data: [
                    randomScalingFactor(),
                    randomScalingFactor(),
                    randomScalingFactor(),
                    randomScalingFactor(),
                    randomScalingFactor(),
                    randomScalingFactor(),
                    randomScalingFactor()
                ]
            }, {
                label: 'Dataset 2',
                backgroundColor: color(window.chartColors.blue).alpha(0.5).rgbString(),
                borderColor: window.chartColors.blue,
                borderWidth: 1,
                data: [
                    randomScalingFactor(),
                    randomScalingFactor(),
                    randomScalingFactor(),
                    randomScalingFactor(),
                    randomScalingFactor(),
                    randomScalingFactor(),
                    randomScalingFactor()
                ]
            }]

        };

        

        

        

            

        

        
    </script>
	<!-- new added graphs chart js-->
	
	<!-- Classie --><!-- for toggle left push menu script -->
		<script src="<?php echo base_url('Assets/Marketing/js/classie.js');?>"></script>
		<script>
			var menuLeft = document.getElementById( 'cbp-spmenu-s1' ),
				showLeftPush = document.getElementById( 'showLeftPush' ),
				body = document.body;
				
			showLeftPush.onclick = function() {
				classie.toggle( this, 'active' );
				classie.toggle( body, 'cbp-spmenu-push-toright' );
				classie.toggle( menuLeft, 'cbp-spmenu-open' );
				disableOther( 'showLeftPush' );
			};
			

			function disableOther( button ) {
				if( button !== 'showLeftPush' ) {
					classie.toggle( showLeftPush, 'disabled' );
				}
			}
		</script>
	<!-- //Classie --><!-- //for toggle left push menu script -->
		
	<!--scrolling js-->
	<script src="<?php echo base_url('Assets/Marketing/js/jquery.nicescroll.js');?>"></script>
	<script src="<?php echo base_url('Assets/Marketing/js/scripts.js');?>"></script>
	<!--//scrolling js-->
	
	<!-- side nav js -->
	<script src='<?php echo base_url('Assets/Marketing/js/SidebarNav.min.js');?>' type='text/javascript'></script>
	<script>
      $('.sidebar-menu').SidebarNav()
    </script>
	<!-- //side nav js -->
	
	<!-- for index page weekly sales java script -->
	<script src="<?php echo base_url('Assets/Marketing/js/SimpleChart.js');?>"></script>
   
	
	
	<!-- Bootstrap Core JavaScript -->
   <script src="<?php echo base_url('Assets/Marketing/js/bootstrap.js');?>"> </script>
	<!-- //Bootstrap Core JavaScript -->
	
</body>
</html>