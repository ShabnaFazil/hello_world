<?php
$this->load->view('Mark/Header');
?>

<?php
$this->load->view('Mark/Footer');
?>