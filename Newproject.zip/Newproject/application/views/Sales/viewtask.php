<?php
$this->load->view('Sales/Header');
?>
<div id="page-wrapper">
			<div class="main-page">
				<div class="tables">
					<h2 class="title1">Tables</h2>
					<div class="panel-body widget-shadow">
						<h4>Tasks</h4>
						<table class="table">
							<thead>
								<tr>
								  <th>Sl No</th>
								  <th>Name</th>
								  <th>Email</th>
								  <th>Task</th>
								  <th>Date</th>
								  <th>Time</th>
								  <th>Send report</th>
								</tr>
							</thead>
							<tbody>
								<?php
									$i=1;
									foreach($tsk as $row)
									{
								?>
								<tr>
								  <th scope="row"><?php echo $i;?></th>
								  <td><?php echo $row->name?></td>
								  <td><?php echo $row->email?></td>
								  <td><?php echo $row->task?></td>
								  <td><?php echo $row->date?></td>
								  <td><?php echo $row->time?></td>
								  <td><button><a href="<?php echo base_url('index.php/Sales/sendreport/'.$row->assignid)?>">Send report</button></a> </td>
								</tr>
								<?php
									$i++;
									}
								?>
							</tbody>
						</table>
					</div>
					
					
					
				</div>
			</div>
		</div>

<?php
$this->load->view('Sales/Footer');
?>