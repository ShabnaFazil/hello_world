<?php
$this->load->view('Sales/Header');
?>
<div id="page-wrapper">
			<div class="main-page">
				<div class="forms">
							<h4>Sending report</h4>
						</div>
						<div class="form-body">
							<form method="post" action="<?php echo base_url('index.php/Sales/reportsend')?>"> 
								<?php
								foreach($tsk as $row);
								?>
								<input type="hidden" class="form-control" id="exampleInputEmail1" placeholder="" name="aid" value="<?php echo $row->assignid?>" >
								<!-- <div class="form-group"> 
									<label for="exampleInputEmail1">Name</label> 
									<input type="text" class="form-control" id="exampleInputEmail1" placeholder="" name="name" value="<?php echo $row->name?>" readonly> 
								</div>
								<div class="form-group"> 
									<label for="exampleInputEmail1">Email</label> 
									<input type="email" class="form-control" id="exampleInputEmail1" placeholder="Email" name="email" value="<?php echo $row->email?>" readonly> 
								</div>  -->
								<div class="form-group"> 
									<label for="exampleInputPassword1">Task</label> 
									<input type="text" class="form-control" id="exampleInputPassword1" placeholder="" name="task" value="<?php echo $row->task?>" readonly> 
								</div> 
								<div class="form-group"> 
									<label for="exampleInputPassword1">Report</label> 
									<input type="text" class="form-control" id="exampleInputPassword1" placeholder="" name="report" > 
								</div> 
						</div> 
						<button type="submit" class="btn btn-default" style="display: inline-block;
    margin-right: 500;
    text-align: center;
    vertical-align: right;
    text-transform: uppercase;
    cursor: pointer;">Submit</button> 
							</form> 
						</div>
					</div>
				</div>
			</div>
<?php
$this->load->view('Sales/Footer');
?>