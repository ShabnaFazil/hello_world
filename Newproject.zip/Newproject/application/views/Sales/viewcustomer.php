<?php
$this->load->view('Sales/Header');
?>
<div id="page-wrapper">
			<div class="main-page">
				<div class="tables">
					<h2 class="title1">Tables</h2>
					<div class="panel-body widget-shadow">
						<h4>Tasks</h4>
						<table class="table">
							<thead>
								<tr>
								  <th>Sl No</th>
								  <th>Name</th>
								  <th>Email</th>
								  <th>Address</th>
								  <th>Mobile</th>
								  <th>Date</th>
								  <th>Edit</th>
								  <th>Delete</th>
								</tr>
							</thead>
							<tbody>
								<?php
									$i=1;
									foreach($cstmr as $row)
									{
								?>
								<tr>
								  <th scope="row"><?php echo $i;?></th>
								  <td><?php echo $row->name?></td>
								  <td><?php echo $row->email?></td>
								  <td><?php echo $row->address?></td>
								  <td><?php echo $row->mobile?></td>
								  <td><?php echo $row->Date?></td>
								  <td><button><a href="<?php echo base_url('index.php/Sales/editcustomer/'.$row->id)?>">Edit</button></a> </td>
								  <td><button><a href="<?php echo base_url('index.php/Sales/deletecustomer/'.$row->id)?>">Delete</button></a> </td>
								</tr>
								<?php
									$i++;
									}
								?>
							</tbody>
						</table>
					</div>
					
					
					
				</div>
			</div>
		</div>

<?php
$this->load->view('Sales/Footer');
?>