<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mark_model extends CI_Model
{
	public function login($log)
	{
		$this->db->where($log);
		return $this->db->count_all_results('marketing');
	}


}