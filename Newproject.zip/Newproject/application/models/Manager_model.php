<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Manager_model extends CI_Model 
{

	public function register($add_register)
	{
		return $this->db->insert('admin',$add_register);
	}
	public function login($login)
	{
		$this->db->where($login);
		return $this->db->count_all_results('admin');
	}
	public function taskadd($t1)
	{
		return $this->db->insert('task',$t1);
	}
	public function viewtask()
	{
		$this->db->select('*');
		$this->db->from('task');
		return $this->db->get()->result();
	}
	public function viewedittask($id)
	{
		$this->db->where('id',$id);
		$this->db->select('*');
		$this->db->from('task');
		return $this->db->get()->result();
	}
	public function taskedit($edit,$id)
	{
		$this->db->where('id',$id);
		return $this->db->update('task',$edit);
	}
	public function deletetask($id)
	{
		$this->db->where('id',$id);
		return $this->db->delete('task');
	}
	public function vieweditmarket($id)
	{
		$this->db->where('id',$id);
		$this->db->select('*');
		$this->db->from('marketing');
		return $this->db->get()->result();
	}
	public function marketedit($editmar,$id)
	{
		$this->db->where('id',$id);
		return $this->db->update('marketing',$editmar);
	}
	public function deletemarket($id)
	{
		$this->db->where('id',$id);
		return $this->db->delete('marketing');
	}
	public function createtask($create)
	{
		return $this->db->insert('assigntask',$create);
	}
	public function marketview()
	{
		$this->db->select('*');
		$this->db->from('assigntask');
		$this->db->join('marketing','marketing.email=assigntask.markid','inner');
		$this->db->join('task','task.id=assigntask.taskid','inner');
		return $this->db->get()->result();
	}



	public function vieweditsale($id)
	{
		$this->db->where('id',$id);
		$this->db->select('*');
		$this->db->from('sales');
		return $this->db->get()->result();
	}
	public function saleedit($editsale,$id)
	{
		$this->db->where('id',$id);
		return $this->db->update('sales',$editsale);
	}
	public function deletesale($id)
	{
		$this->db->where('id',$id);
		return $this->db->delete('sales');
	}
	public function createtask1($create)
	{
		return $this->db->insert('assigntask',$create);
	}
	public function saleview()
	{
		$this->db->select('*');
		$this->db->from('assigntask');
		$this->db->join('sales','sales.email=assigntask.salesid','inner');
		$this->db->join('task','task.id=assigntask.taskid','inner');
		return $this->db->get()->result();
	}
	public function viewsale()
	{
		$this->db->select('*');
		$this->db->from('sales');
		return $this->db->get()->result();
	}
	public function countmarket()
	{
		$this->db->select('*');
		$this->db->from('marketing');
		return $this->db->count_all_results();
	}
	public function countsales()
	{
		$this->db->select('*');
		$this->db->from('sales');
		return $this->db->count_all_results();
	}
}
