<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sales_model extends CI_Model 
{
	public function register($add)
	{
		return $this->db->insert('sales',$add);
	}
	public function login($log)
	{
		$this->db->where($log);
		return $this->db->count_all_results('sales');
	}
	public function viewsales()
	{
		$this->db->select('*');
		$this->db->from('sales');
		return $this->db->get()->result();
	}
	public function viewtask()
	{
		$email=$this->session->userdata('email');
		$this->db->where('salesid',$email);
		$this->db->select('*');
		$this->db->from('assigntask');
		$this->db->join('sales','assigntask.salesid=sales.email','inner');
		$this->db->join('task','assigntask.taskid=task.id','inner');
		return $this->db->get()->result();
	}
	public function viewtasksale($id)
	{
		$email=$this->session->userdata('email');
		$this->db->where('assignid',$id);
		$this->db->select('*');
		$this->db->from('assigntask');
		$this->db->join('task','assigntask.taskid=task.id','inner');
		return $this->db->get()->result();
	}
	public function updatetask($update,$aid)
	{
		$this->db->where('assignid',$aid);
		return $this->db->update('assigntask',$update);
	}
	public function customer($add)
	{
		return $this->db->insert('customer',$add);
	}
	public function viewcustomer()
	{
		$email=$this->session->userdata('email');
		$this->db->where('salemail',$email);
		$this->db->select('*');
		$this->db->from('customer');
		return $this->db->get()->result();
	}
	public function viewcustomer1($id)
	{
		$email=$this->session->userdata('email');
		$this->db->where('salemail',$email);
		$this->db->where('id',$id);
		$this->db->select('*');
		$this->db->from('customer');
		return $this->db->get()->result();
	}
	public function customeredit($add,$id)
	{
		$this->db->where('id',$id);
		return $this->db->update('customer',$add);
	}
	public function customerdelete($id)
	{
		$this->db->where('id',$id);
		return $this->db->delete('customer');
	}
	public function profile()
	{
		$email=$this->session->userdata('email');
		$this->db->where('email',$email);
		$this->db->select('*');
		$this->db->from('sales');
		return $this->db->get()->result();
	}
	public function profileedit($add)
	{
		$email=$this->session->userdata('email');
		$this->db->where('email',$email);
		return $this->db->update('sales',$add);
	}
	public function counttask()
	{
		$email=$this->session->userdata('email');
		$this->db->where('salesid',$email);
		return $this->db->count_all_results('assigntask');
	}
	public function countuser()
	{
		$email=$this->session->userdata('email');
		$this->db->where('salemail',$email);
		return $this->db->count_all_results('customer');
	}
}